The `Data` directory contains all the crawled and annotated data smaples.

Here is the description of the file and directory structure. 

```
Data 
	AllSides_Data 
		1. train_news.xlsx - Training Data crawled from AllSides
		   Columns - Key, Left, Right, AllSides Annotation, Flag
		   Flag = 0 (Valid Train Sample), Flag = 1 (Invalid Train Sample)

		2. test_news_raw.xlsx - Raw Test data crawled from AllSides
		   Columns - Key, Left, Right, AllSides Annotation
		   	   
		3. test_news_truncated.xlsx - In this case, columns labelled `Left` and `Right` are concatenated to max length of 512  becasue 1) requirement for T5 model 2) to have consistency across all the models. It also contains human wriiten (reference) intersection-summary. Thus, in total 4 refernece intersections.

	Label_Annotation
		Direct_Label_Annotation
			1. 25_samples_One_Number.xlsx - 25 samples with only single numeric score                (2 annotators)
			2. 25_samples_Two_Number.xlsx - 25 samples with two numeric score (precision and recall) (3 annotators)

		Sentence_Wise_Label_Annotation // Sentence-wise labelled data files by different label annotators
			1. Label_Annotator_1.xlsx (L1)
			2. Label_Annotator_2.xlsx (L2)
			3. Label_Annotator_3.xlsx (L3)

```	
